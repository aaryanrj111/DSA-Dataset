

class Solution
{
    //Function to return the minimum cost to react at bottom
	//right cell from top left cell.
    public int minimumCostPath(int[][] grid)
    {
        // Code here
        
        int a = minimumCostPathSol(grid, r,j-1, val, visited);
        int a = minimumCostPathSol(grid, r,j-1, val, visited);
        int a = minimumCostPathSol(grid, r,j-1, val, visited);
    }
}